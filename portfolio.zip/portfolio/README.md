# Elliot — Filmmaker Portfolio

A minimal, cinematic portfolio site for GitHub Pages. No frameworks, no build step — pure HTML, CSS, and vanilla JS.

---

## Quick setup

### 1. Get it on GitHub Pages

1. Create a new GitHub repo (e.g. `elliot-portfolio` or `yourusername.github.io`)
2. Upload all these files (keeping the folder structure)
3. Go to **Settings → Pages → Source** and set it to the `main` branch, root `/`
4. Your site will be live at `https://yourusername.github.io/repo-name/`

---

## Customisation checklist

### Your name & details
- Open `index.html`
- Find `Elliot` in the hero section and update to your full name or preferred credit
- Update the `<title>` tag and `<meta name="description">` at the top
- Update the email in the contact section: `hello@yourdomain.co.uk`
- Update Instagram, Vimeo, and IMDb links throughout

### Showreel (hero video)
- The hero uses a Vimeo background embed by default
- Replace the `src` in the `<iframe>` with your own Vimeo embed URL:
  ```
  https://player.vimeo.com/video/YOUR_VIDEO_ID?autoplay=1&muted=1&loop=1&background=1
  ```
- Or swap it for a YouTube embed — the CSS will handle the fullscreen sizing

### Project cards
- Each `<article class="project-card">` is one project
- Add/remove cards as needed — the grid handles 2, 3, or 4 columns automatically
- Fill in: the `href` on the link (Vimeo/YouTube URL or a detail page), your role, year, title, and type
- Thumbnails go in `assets/` — name them `thumb-01.jpg`, `thumb-02.jpg` etc, or update the `src` attributes

### About section
- Update the two `<p class="about-body">` paragraphs with your actual bio
- Update the Roles, Formats, and Tools lists
- Add a portrait or on-set photo as `assets/portrait.jpg`

### Scroll reveal
- Any element with `class="reveal"` will fade up when scrolled into view
- Add `class="reveal-stagger"` to a container to stagger its direct children

---

## File structure

```
portfolio/
├── index.html          ← Main page (everything is here)
├── css/
│   └── style.css       ← All styles
├── js/
│   └── main.js         ← Nav scroll, mobile menu, reveal animation
├── assets/
│   ├── thumb-01.jpg    ← Project thumbnails
│   ├── thumb-02.jpg
│   └── portrait.jpg    ← Your about photo
└── README.md
```

---

## Adding more pages

The nav is set up for a single-page scroll site. If you want separate pages for individual projects, just duplicate `index.html`, rename it (e.g. `project-one.html`), and link to it from the project card's `href`.

---

## Fonts

Using Google Fonts (loaded via CDN):
- **Cormorant Garamond** — headings and hero
- **Inter** — nav, body, labels

If you want to self-host fonts (better for performance/privacy), download them from [google-webfonts-helper](https://gwfh.madebyeugene.com/) and update the `@import` in `style.css`.
